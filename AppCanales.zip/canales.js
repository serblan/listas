const https = require('https');
const { DOMParser } = require('xmldom');
const { exec } = require('child_process');
const readline = require('readline');

const epgUrl = 'https://raw.githubusercontent.com/davidmuma/EPG_dobleM/master/guiatv.xml';
const acestreamUrl = 'https://raw.githubusercontent.com/serblan/listas/main/ace';
const updateInterval = 60 * 1000; // Intervalo de actualización: cada 60 segundos

let playerProcess;
let currentChannel = null;

function fetchData(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (response) => {
            let data = '';
            response.on('data', (chunk) => data += chunk);
            response.on('end', () => resolve(data));
        }).on('error', (error) => reject(error));
    });
}

async function loadExternalContent() {
    try {
        const acestreamData = await fetchData(acestreamUrl);
        const epgData = await fetchData(epgUrl);

        const channels = [];
        const lines = acestreamData.split('\n');
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line === '#EXTM3U') continue;

            const logoMatch = line.match(/tvg-logo="([^"]+)"/);
            const tvgIdMatch = line.match(/tvg-id="([^"]+)"/);
            const channelNameMatch = line.match(/,(.+)$/);

            if (tvgIdMatch && channelNameMatch) {
                const tvgId = tvgIdMatch[1];
                const channelName = channelNameMatch[1].trim();
                const logoURL = logoMatch ? logoMatch[1] : 'Sin Logo';
                const acestreamURL = (i + 1 < lines.length && lines[i + 1].includes('acestream://')) ? lines[i + 1].trim() : '';

                channels.push({
                    logoURL,
                    tvgId,
                    channelName,
                    acestreamURL
                });
                i++;
            }
        }

        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(epgData, 'text/xml');

        const eventsMap = {};
        Array.from(xmlDoc.getElementsByTagName('programme')).forEach(programme => {
            const channelId = programme.getAttribute('channel');
            const title = programme.getElementsByTagName('title')[0].textContent;
            const start = programme.getAttribute('start');
            const stop = programme.getAttribute('stop');

            if (!eventsMap[channelId]) eventsMap[channelId] = [];
            eventsMap[channelId].push({ title, start, stop });
        });

        function getCurrentEvent(events) {
            const now = new Date();
            now.setHours(now.getHours() + 1); // Sumar una hora para ajustar al huso horario deseado
        
            for (let event of events) {
                const { title, start, stop } = event;
                const startTime = new Date(`${start.slice(0, 4)}-${start.slice(4, 6)}-${start.slice(6, 8)}T${start.slice(8, 10)}:${start.slice(10, 12)}:00Z`).getTime();
                const stopTime = new Date(`${stop.slice(0, 4)}-${stop.slice(4, 6)}-${stop.slice(6, 8)}T${stop.slice(8, 10)}:${stop.slice(10, 12)}:00Z`).getTime();
        
                if (startTime <= now.getTime() && now.getTime() < stopTime) {
                    return `${title} (${start.slice(8, 10)}:${start.slice(10, 12)} - ${stop.slice(8, 10)}:${stop.slice(10, 12)})`;
                }
            }
            return `Sin evento`;
        }
        
        

        function updateEventsDisplay() {
            const tableData = channels.map(channel => {
                const { tvgId, channelName } = channel;
                let currentEvent = 'Sin evento';

                if (eventsMap[tvgId]) {
                    const events = eventsMap[tvgId];
                    currentEvent = getCurrentEvent(events);
                }

                return {
                    Canal: channelName,
                    'Evento Actual': currentEvent
                };
            }).filter(channel => channel);

            console.clear();
            console.table(tableData);
        }

        updateEventsDisplay(); // Mostrar la primera vez
        setInterval(updateEventsDisplay, updateInterval); // Actualizar en intervalos

        selectChannel(channels);

    } catch (error) {
        console.error('Error al cargar contenido externo:', error);
    }
}

function selectChannel(channels) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    const askForChannel = () => {
        rl.question('Seleccione el número del canal (o escriba EXIT para cerrar): ', async (answer) => {
            if (answer.toString() === 'EXIT') {
                if (playerProcess) {
                    exec('taskkill /F /IM ace_player.exe', console.log('AceStream cerrado.'));
                } else {
                    console.log('No hay proceso de AceStream en ejecución.');
                }
                rl.close();
                return;
            }

            const index = parseInt(answer);
            if (!isNaN(index) && index >= 0 && index < channels.length) {
                const channel = channels[index];
                const acestreamURL = channel.acestreamURL;

                if (acestreamURL) {
                    if (currentChannel !== null) {
                        console.log(`Cerrando el canal actual: ${channels[currentChannel].Canal}`);
                        exec('taskkill /F /IM ace_player.exe', (err) => {
                            if (!err) {
                                console.log('Esperando 5 segundos para reiniciar el canal...');
                                setTimeout(() => {
                                    console.log(`Iniciando el nuevo canal: ${channel.Canal}`);
                                    startAceStream(acestreamURL);
                                }, 5000);
                            }
                        });
                    } else {
                        console.log(`Iniciando el canal: ${channel.Canal}`);
                        startAceStream(acestreamURL);
                    }

                    currentChannel = index;
                } else {
                    console.log('No hay URL de acestream disponible para este canal.');
                }
            } else {
                console.log('Índice no válido, por favor intente nuevamente.');
            }
            
            askForChannel();
        });
    };

    askForChannel();
}

function startAceStream(acestreamURL) {
    if (!acestreamURL) {
        console.error('URL de AceStream no disponible.');
        return;
    }

    playerProcess = exec(`"C:\\Users\\Sergio\\AppData\\Roaming\\ACEStream\\player\\ace_player.exe" "${acestreamURL}"`, (err) => {
        if (!err) {
            console.log('AceStream debería estar ejecutándose.');
        }
    });
}

loadExternalContent();
