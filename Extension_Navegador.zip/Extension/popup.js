document.addEventListener('DOMContentLoaded', function () {
    const statusElement = document.getElementById('status');
    const tablaElement = document.getElementById('tablaCanales').querySelector('tbody');

    // URLs de los archivos remotos
    const acestreamURL = 'https://raw.githubusercontent.com/serblan/listas/main/ace';
    const epgURL = 'https://raw.githubusercontent.com/dracohe/CARLOS/master/guide_IPTV.xml';

    // Función para obtener los datos de un archivo remoto
    async function obtenerDatos(url) {
        const respuesta = await fetch(url);
        return await respuesta.text();
    }

    // Función para procesar los datos de Acestream
    function procesarAcestream(datos) {
        const canales = [];
        const lineas = datos.split('\n');

        lineas.forEach(linea => {
            if (linea.startsWith("#EXTINF")) {
                const canal = {};

                // Extraer el tvg-id del canal
                const tvgIdMatch = linea.match(/tvg-id="([^"]+)"/);
                canal.tvgId = tvgIdMatch ? tvgIdMatch[1] : '';

                // Extraer el logo del canal
                const logoMatch = linea.match(/tvg-logo="([^"]+)"/);
                canal.logo = logoMatch ? logoMatch[1] : '';

                // Extraer el nombre del canal
                const nombreMatch = linea.match(/,(.+)$/);
                canal.nombre = nombreMatch ? nombreMatch[1] : '';

                // Extraer el enlace acestream
                const indexLinea = lineas.indexOf(linea);
                const enlace = lineas[indexLinea + 1];
                if (enlace && enlace.startsWith("acestream://")) {
                    canal.enlace = enlace;
                }

                canales.push(canal);
            }
        });

        return canales;
    }

    // Función para procesar los datos de EPG
    function procesarEPG(datos) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(datos, 'text/xml');
        const eventos = {};

        // Obtener todos los eventos del EPG
        const programas = xmlDoc.getElementsByTagName('programme');
        for (let i = 0; i < programas.length; i++) {
            const programa = programas[i];
            const canalId = programa.getAttribute('channel');
            const start = programa.getAttribute('start');
            const titulo = programa.getElementsByTagName('title')[0].textContent;

            if (!eventos[canalId]) {
                eventos[canalId] = [];
            }

            eventos[canalId].push({
                start: start,
                titulo: titulo
            });
        }

        return eventos;
    }

    // Función para determinar el evento actual y los siguientes dos
    function obtenerEventosActuales(eventos, canalId) {
        const ahora = new Date();
        const eventosCanal = eventos[canalId] || [];
    
        let eventoActual = null;
        let futurosEventos = [];
    
        // Primero, obtener todos los eventos para el canal y ordenarlos
        const eventosOrdenados = eventosCanal.map(evento => {
            const startDateUTC = new Date(
                `${evento.start.slice(0, 4)}-${evento.start.slice(4, 6)}-${evento.start.slice(6, 8)}T${evento.start.slice(8, 10)}:${evento.start.slice(10, 12)}:${evento.start.slice(12, 14)}Z`
            );
            // Convertir la fecha UTC a la hora local
            const startDateLocal = new Date(startDateUTC.getTime() + startDateUTC.getTimezoneOffset() * 60000);
            return { ...evento, startDateLocal };
        }).sort((a, b) => a.startDateLocal - b.startDateLocal); // Ordenar por fecha
    
        // Encontrar el evento actual y los futuros
        for (let i = 0; i < eventosOrdenados.length; i++) {
            const evento = eventosOrdenados[i];
    
            if (evento.startDateLocal <= ahora) {
                eventoActual = evento;
            } else if (evento.startDateLocal > ahora && futurosEventos.length < 2) {
                futurosEventos.push(evento);
            }
        }
    
        // Si hay eventos futuros, actualiza la lista de eventos futuros para tener en cuenta el nuevo evento actual
        if (eventoActual) {
            // El primer futuro evento es el próximo evento después del actual
            if (futurosEventos.length > 0 && futurosEventos[0].startDateLocal <= ahora) {
                futurosEventos.shift(); // Elimina el evento que ya ha pasado y agrega el siguiente
            }
        }
    
        // Función para formatear la hora en (HH:MM)
        function formatearHora(start) {
            const startDate = new Date(
                `${start.slice(0, 4)}-${start.slice(4, 6)}-${start.slice(6, 8)}T${start.slice(8, 10)}:${start.slice(10, 12)}:${start.slice(12, 14)}Z`
            );
            // Convertir la fecha UTC a la hora local
            const startDateLocal = new Date(startDate.getTime() + startDate.getTimezoneOffset() * 60000);
            const horas = startDateLocal.getHours().toString().padStart(2, '0');
            const minutos = startDateLocal.getMinutes().toString().padStart(2, '0');
            return `${horas}:${minutos}`;
        }
    
        return {
            actual: eventoActual ? { ...eventoActual, start: formatearHora(eventoActual.start) } : null,
            futuros: futurosEventos.map(evento => ({ ...evento, start: formatearHora(evento.start) }))
        };
    }
    
    // Función para generar la tabla de canales
    function generarTabla(canales, eventos) {
        canales.forEach(canal => {
            const fila = document.createElement('tr');

            // Columna del logo
            const celdaLogo = document.createElement('td');
            const img = document.createElement('img');
            img.src = canal.logo;
            img.alt = canal.nombre;
            img.style.width = '50px';
            celdaLogo.appendChild(img);
            fila.appendChild(celdaLogo);

            // Columna del nombre del canal con enlace
            const celdaCanal = document.createElement('td');
            const enlace = document.createElement('a');
            enlace.href = canal.enlace;
            enlace.textContent = canal.nombre;
            enlace.style.color = "inherit";
            enlace.style.textDecoration = "none";
            celdaCanal.appendChild(enlace);
            fila.appendChild(celdaCanal);

            // Obtener eventos actuales y futuros
            const eventosCanal = obtenerEventosActuales(eventos, canal.tvgId);

            // Columna del evento actual
            const celdaEventoActual = document.createElement('td');
            if (eventosCanal.actual) {
                celdaEventoActual.textContent = `${eventosCanal.actual.titulo} (${eventosCanal.actual.start})`;
            } else {
                celdaEventoActual.textContent = 'N/A';
            }
            fila.appendChild(celdaEventoActual);

            // Columnas de los dos eventos futuros
            for (let i = 0; i < 2; i++) {
                const celdaEventoFuturo = document.createElement('td');
                if (eventosCanal.futuros[i]) {
                    celdaEventoFuturo.textContent = `${eventosCanal.futuros[i].titulo} (${eventosCanal.futuros[i].start})`;
                } else {
                    celdaEventoFuturo.textContent = 'N/A';
                }
                fila.appendChild(celdaEventoFuturo);
            }

            tablaElement.appendChild(fila);
        });
    }

    // Función principal para cargar y mostrar los datos
    async function cargarDatos() {
        try {
            const [acestreamDatos, epgDatos] = await Promise.all([
                obtenerDatos(acestreamURL),
                obtenerDatos(epgURL)
            ]);

            const canales = procesarAcestream(acestreamDatos);
            const eventos = procesarEPG(epgDatos);

            generarTabla(canales, eventos);
            statusElement.style.display = 'none'; // Ocultar el estado de carga
        } catch (error) {
            statusElement.textContent = 'Error al cargar los datos: ' + error;
        }
    }

    cargarDatos();
});
