const fetch = require('node-fetch'); // Asegúrate de instalar node-fetch ejecutando: npm install node-fetch

(async function() {
    // URL del archivo base.txt
    const urlBase = 'https://actualsebastian.vercel.app/base.txt';

    // URL de la lista de referencia
    const urlReferencia = 'https://raw.githubusercontent.com/serblan/listas/main/ace';

    // URL del servicio ntfy.sh para enviar la notificación
    const urlNtfy = 'https://ntfy.sh/7us6sdOdGVEjgILifava2asdfADasd1AdasdXASx1';

    // Frases de inicio permitidas para los nombres de canales
    const inicioCanalesPermitidos = [
        "DAZN LaLiga 1080 MultiAudio",
        "DAZN LaLiga 720",
        "DAZN LaLiga 2 1080 MultiAudio",
        "M+ LaLiga 1080P",
        "M+ LaLiga 1080 MultiAudio",
        "M+ LaLiga 720",
        "M+ LaLiga 2 1080",
        "M+ LaLiga 2 720",
        "LaLiga HyperMotion 1080",
        "LaLiga HyperMotion 720",
        "LaLiga HyperMotion 2 1080",
        "ML Campeones 1080 MultiAudio",
        "ML Campeones 720",
        "ML Campeones 2 1080",
        "ML Campeones 2 720",
        "ML Campeones 3 1080",
        "ML Campeones 4 1080",
        "ML Campeones 5 1080",
        "M+ Deportes 1080",
        "M+ Deportes 2 1080",
        "M+ Golf 1080",
        "DAZN 1 1080",
        "DAZN 2 1080",
        "DAZN F1 1080",
        "DAZN F1 720",
        "EuroSport 1 1080",
        "EuroSport 2 1080",
        "#Vamos 1080",
        "M Plus+ 1080"
    ];

    try {
        // Fetch del archivo base.txt
        const responseBase = await fetch(urlBase);
        if (!responseBase.ok) throw new Error('Error al obtener el archivo base');
        const textBase = await responseBase.text();

        // Fetch de la lista de referencia
        const responseReferencia = await fetch(urlReferencia);
        if (!responseReferencia.ok) throw new Error('Error al obtener la lista de referencia');
        const textReferencia = await responseReferencia.text();

        // Expresión regular para extraer enlaces acestream y nombres de canal
        const regex = /#EXTINF:-1.*?,(.*?)\nacestream:\/\/(\S+)/g;
        const enlacesNoEncontrados = [];
        let match;

        // Procesa cada coincidencia en el archivo base
        while ((match = regex.exec(textBase)) !== null) {
            const canal = match[1].trim();       // Nombre del canal
            const enlace = `acestream://${match[2]}`; // Enlace acestream

            // Solo procesa el canal si su nombre empieza con una de las frases de inicio permitidas
            if (inicioCanalesPermitidos.some(inicio => canal.startsWith(inicio))) {

                // Solo añade el enlace si no está en la lista de referencia
                if (!textReferencia.includes(enlace)) {
                    enlacesNoEncontrados.push(`${canal}: ${enlace}`);
                }
            }
        }

        // Si hay enlaces no encontrados, envía una notificación a ntfy.sh
        if (enlacesNoEncontrados.length > 0) {
            const mensaje = enlacesNoEncontrados.join('\n');

            await fetch(urlNtfy, {
                method: 'POST',
                headers: {
                    'Title': 'Enlaces AceStream No Encontrados',
                    'Priority': 'high'
                },
                body: mensaje
            });

            console.log('Notificación enviada con éxito con los enlaces no encontrados.');
        } else {
            await fetch(urlNtfy, {
                method: 'POST',
                headers: {
                    'Title': 'No hay cambios de enlaces',
                    'Priority': 'high'
                },
                body: 'Todos los canales estan al dia en git',
            });
            console.log('No se encontraron nuevos enlaces.');
        }

    } catch (error) {
        console.error('Hubo un error:', error);
    }
})();
